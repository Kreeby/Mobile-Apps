//
//  TicketViewController.swift
//  TransportPay
//
//  Created by Rashad on 1/16/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.
//

import UIKit
import FoldingCell

enum Const {
    static let closeCellHeight: CGFloat = 110
    static let openCellHeight: CGFloat = 240
    static let rowsCount = 5
}

var cellHeights: [CGFloat] = []



class TicketViewController: UITableViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.setContentOffset(CGPoint(x: 0, y: -UIScreen.main.bounds.height), animated: true)
        setup()

    }
    
    private func setup() {
            cellHeights = Array(repeating: UIScreen.main.bounds.width*0.3, count: Const.rowsCount)
            tableView.estimatedRowHeight = UIScreen.main.bounds.width*0.3
            tableView.rowHeight = UITableView.automaticDimension
            tableView.backgroundColor = UIColor(red: 243/255, green: 246/255, blue: 249/255, alpha: 1.00)
//            tableView.backgroundColor = CIColor(patternImage: .white)
            if #available(iOS 10.0, *) {
                tableView.refreshControl = UIRefreshControl()
                tableView.refreshControl?.addTarget(self, action: #selector(refreshHandler), for: .valueChanged)
            }
    }
        
        @objc func refreshHandler() {
            let deadlineTime = DispatchTime.now() + .seconds(1)
            DispatchQueue.main.asyncAfter(deadline: deadlineTime, execute: { [weak self] in
                if #available(iOS 10.0, *) {
                    self?.tableView.refreshControl?.endRefreshing()
                }
                self?.tableView.reloadData()
            })
        }
    }
    
    // MARK: - TableView
    extension TicketViewController {
        
        override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
            return 5
        }
        
        override func tableView(_: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
            guard case let cell as DemoCell = cell else {
                return
            }
            cell.backgroundColor = UIColor(red: 243/255, green: 246/255, blue: 249/255, alpha: 1.00)
//            cell.backgroundColor = .clear
            
            if cellHeights[indexPath.row] == UIScreen.main.bounds.width*0.3 {
                cell.unfold(false, animated: false, completion: nil)
            } else {
                cell.unfold(true, animated: false, completion: nil)
            }
            
       cell.number = indexPath.row
        
        }
        
        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FoldingCell", for: indexPath) as! FoldingCell
            let durations: [TimeInterval] = [0.26, 0.2, 0.2]
            cell.durationsForExpandedState = durations
            cell.durationsForCollapsedState = durations
            return cell
        }
        
        override func tableView(_: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return cellHeights[indexPath.row]
        }
        
        override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            let cell = tableView.cellForRow(at: indexPath) as! FoldingCell
            
            
            
            if cell.isAnimating() {
                return
            }
            
            var duration = 0.0
            let cellIsCollapsed = cellHeights[indexPath.row] == UIScreen.main.bounds.width*0.3
            if cellIsCollapsed {
                cellHeights[indexPath.row] = UIScreen.main.bounds.width*0.6
                cell.unfold(true, animated: true, completion: nil)
                duration = 0.5
            } else {
                cellHeights[indexPath.row] = UIScreen.main.bounds.width*0.3
                cell.unfold(false, animated: true, completion: nil)
                duration = 0.8
            }
            
            UIView.animate(withDuration: duration, delay: 0, options: .curveEaseOut, animations: { () -> Void in
                tableView.beginUpdates()
                tableView.endUpdates()
            }, completion: nil)
        }
    }

