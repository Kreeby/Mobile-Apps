import FoldingCell
import UIKit

class DemoCell: FoldingCell {
    
    
    @IBOutlet var busNumber: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var expirationDate: UILabel!
    @IBOutlet weak var priceOpened: UILabel!
    @IBOutlet weak var dateOpened: UILabel!
    @IBOutlet weak var busNumberOpened: UILabel!
    
    
    
    
    var number: Int = 0 {
        didSet {
            if(number==0){
                busNumber.text = "Bus 123"
                price.text = "$0.30"
                date.text = "12/03/2017"
                time.text = "14:00"
                busNumberOpened.text = "Bus 123"
                priceOpened.text = "$0.30"
                dateOpened.text = "12/03/2017"
                expirationDate.text = "Ticket will expire at 12:41"
            }
            if(number==1){
                busNumber.text = "Bus 79"
                price.text = "$0.30"
                time.text = "14:33"
                date.text = "11/03/2017"
                busNumberOpened.text = "Bus 79"
                priceOpened.text = "$0.30"
                dateOpened.text = "11/03/2017"
                expirationDate.text = "Ticket has expired"
            }
            if(number==2){
                busNumber.text = "Trum 1"
                price.text = "$0.25"
                time.text = "14:33"
                date.text = "11/03/2017"
                busNumberOpened.text = "Trum 1"
                priceOpened.text = "$0.25"
                dateOpened.text = "11/03/2017"
                expirationDate.text = "Ticket has expired"
            }
            if(number==3){
                busNumber.text = "Trolleybus 33"
                price.text = "$0.30"
                time.text = "12:06"
                date.text = "10/03/2017"
                busNumberOpened.text = "Trolleybus 33"
                priceOpened.text = "$0.30"
                dateOpened.text = "10/03/2017"
                expirationDate.text = "Ticket has expired"
            }
            if(number==4){
                busNumber.text = "Bus 12"
                price.text = "$0.30"
                time.text = "8:12"
                date.text = "09/03/2017"
                busNumberOpened.text = "Bus 12"
                priceOpened.text = "$0.30"
                dateOpened.text = "09/03/2017"
                expirationDate.text = "Ticket has expired"
            }
            
        }
    }


    override func awakeFromNib() {
        foregroundView.layer.cornerRadius = 10
        foregroundView.layer.masksToBounds = true
        super.awakeFromNib()
    }

    override func animationDuration(_ itemIndex: NSInteger, type _: FoldingCell.AnimationType) -> TimeInterval {
        let durations = [0.26, 0.2, 0.2]
        return durations[itemIndex]
    }
}

// MARK: - Actions ⚡️
//extension DemoCell {
//    
//    @IBAction func buttonHandler(_: AnyObject) {
//        print("tap")
//    }
//}
