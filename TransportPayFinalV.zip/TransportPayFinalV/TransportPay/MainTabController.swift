//
//  MainTabController.swift
//  TransportPay
//
//  Created by Rashad on 1/13/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.
//

import Foundation
import UIKit


class MainTabController:  UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
