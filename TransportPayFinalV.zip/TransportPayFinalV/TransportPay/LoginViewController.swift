//
//  ViewController.swift
//  TransportPay
//
//  Created by Rashad on 1/11/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.
//

import UIKit
import Foundation

class LoginViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    var gradientLayer: CAGradientLayer!
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countryNames.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countryNames[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCountry = countryNames[row]
        textFieldPicker.text = selectedCountry
        if (selectedCountry == "Azerbaijan") {
            phoneCode.text = "+994"
        }
        else {
            phoneCode.text = "+375"
        }
       
    }
    
    func createPickerView(){
        let pickerView = UIPickerView()
        pickerView.delegate = self
        
        textFieldPicker.inputView = pickerView
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        createGradientLayer()
    }
    
    func createGradientLayer() {
        gradientLayer = CAGradientLayer()
        gradientLayer.frame = signUpBtn.bounds
        gradientLayer.colors = [ UIColor.init(red: 78/255, green: 56/255, blue: 226/255, alpha: 1).cgColor, UIColor(red: 157/255, green: 27/255, blue: 248/255, alpha: 1).cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        
        signUpBtn.layer.addSublayer(gradientLayer)
    }
    
    override func viewDidLayoutSubviews() {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientLayer.frame = signUpBtn.bounds
        CATransaction.commit()
    }
    
    
    var selectedCountry: String?
    var selectedPhoneCodeNum: String?
    var countryNames = ["Belarus", "Azerbaijan"]
    
   
//    func dissmissPickerView() {
//        let toolBar = UIToolbar()
//        toolBar.sizeToFit()
//
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.dissmissKeyboard))
//        toolBar.setItems([doneButton], animated: false)
//        toolBar.isUserInteractionEnabled = true
//
//        textFieldPicker.inputAccessoryView = toolBar
//
//    }
//
//
//    @objc func dissmissKeyboard(){
//        view.endEditing(true)
//    }
    
    @IBOutlet weak var textFieldPicker: UITextField!
    @IBOutlet weak var phoneCode: UILabel!
    
    @IBOutlet weak var phoneTextField: UITextField!
    
    
    @IBOutlet weak var signUpBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
        self.hideKeyboardWhenTappedAround()
        createPickerView()
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        textFieldPicker.backgroundColor = UIColor.clear
        textFieldPicker.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
      
        phoneTextField.backgroundColor = UIColor.clear
        phoneTextField.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        
        signUpBtn.layer.cornerRadius = 20.5
        signUpBtn.clipsToBounds = true

        
//        signUpBtn.setGradientBackground(colorOne:  UIColor.init(displayP3Red: 157/255, green: 27/255, blue: 248/255, alpha: 1), colorTwo: UIColor.init(displayP3Red: 78/255, green: 56/255, blue: 226/255, alpha: 1))
//
        
//        bottomGrad.setGradientBackgroundBottom(colorOne: UIColor.init(displayP3Red: 0/255, green: 0/255, blue: 0/255, alpha: 1), colorTwo: UIColor.init(displayP3Red: 0/255, green: 0/255, blue: 0/255, alpha: 0.15))
        
//        bottomView.setGradientBackgroundBottom(colorOne: UIColor.init(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 0), colorTwo:  UIColor.init(displayP3Red: 0/255, green: 0/255, blue: 0/255, alpha: 0.10))
        
        
        
        
        let attributes = [
            NSAttributedString.Key.foregroundColor: UIColor.gray,
            NSAttributedString.Key.font : UIFont(name: "Lato", size: 12)! // Note the !
        ]
        
        phoneTextField.attributedPlaceholder = NSAttributedString(string: "Enter your phone number", attributes:attributes)
        
    }
    
    

    
    @IBAction func loginTapped(_ sender: Any) {
        let mainTabController = storyboard?.instantiateViewController(withIdentifier: "MainTabController") as! MainTabController
        
        present(mainTabController, animated: true, completion: nil)
    }
    
   
    
}


extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
