//
//  qrcodeViewController.swift
//  TransportPay
//
//  Created by Rashad on 1/13/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import BarcodeScanner

class QrcodeViewController: UIViewController {
    
    @IBOutlet weak var grayView: UIView!
    
    var style:UIStatusBarStyle = .default

    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return self.style
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        grayView.layer.cornerRadius = 12.5
        grayView.layer.masksToBounds = true
        
    }
    
    
    func createAlert(title:String, message:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(action) in alert.dismiss(animated: true, completion: nil)}))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func tapToOpen(_ sender: Any) {
        let viewController = makeBarcodeScannerViewController()
        viewController.title = "Barcode Scanner"
        present(viewController, animated: true, completion: nil)
    }
    
    
    
    private func makeBarcodeScannerViewController() -> BarcodeScannerViewController {
        let viewController = BarcodeScannerViewController()
        viewController.codeDelegate = self as? BarcodeScannerCodeDelegate
        viewController.errorDelegate = self as? BarcodeScannerErrorDelegate
        viewController.dismissalDelegate = self as? BarcodeScannerDismissalDelegate
        return viewController
    }
}



// MARK: - BarcodeScannerCodeDelegate

extension QrcodeViewController: BarcodeScannerCodeDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
        print("Barcode Data: \(code)")
        print("Symbology Type: \(type)")
        
    
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
            controller.resetWithError()
            controller.dismiss(animated: true, completion: nil)
            self.createAlert(title: "Your Barcode", message: code)
        }
    }
}

// MARK: - BarcodeScannerErrorDelegate

extension QrcodeViewController: BarcodeScannerErrorDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didReceiveError error: Error) {
        print(error)
    }
}

// MARK: - BarcodeScannerDismissalDelegate

extension QrcodeViewController: BarcodeScannerDismissalDelegate {
    func scannerDidDismiss(_ controller: BarcodeScannerViewController) {
        controller.dismiss(animated: true, completion: nil)
        

    }
}
