//  Created by Rashad on 1/11/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.

import UIKit

@IBDesignable
class TicketClosed: UIView {
    
    override func draw(_ rect: CGRect) {
        UIColor.white.setFill()
        let path1 = UIBezierPath()
        path1.move(to: CGPoint(x: 7.5, y: 2.5))
        path1.addLine(to: CGPoint(x: 347.5, y: 2.5))
        path1.addArc(withCenter: CGPoint(x: 347.5, y: 10), radius: 7.5, startAngle: -.pi/2, endAngle: 0, clockwise: true)
        path1.addLine(to: CGPoint(x: 355, y: 77.5))
        path1.addArc(withCenter: CGPoint(x: 347.5, y: 77.5), radius: 7.5, startAngle: 0, endAngle: .pi/2, clockwise: true)
        path1.addLine(to: CGPoint(x: 7.5, y: 85))
        path1.addArc(withCenter: CGPoint(x: 7.5, y: 77.5), radius: 7.5, startAngle: .pi/2, endAngle: .pi, clockwise: true)
        path1.addLine(to: CGPoint(x: 0, y: 10))
        path1.addArc(withCenter: CGPoint(x: 7.5, y: 10), radius: 7.5, startAngle: -.pi, endAngle:-.pi/2 , clockwise: true)
        path1.close()
        path1.fit(into: rect).moveCenter(to: rect.center).fill()
        path1.lineWidth = 0.0
        path1.lineCapStyle = .butt
        path1.stroke()
    }
    
    
}
