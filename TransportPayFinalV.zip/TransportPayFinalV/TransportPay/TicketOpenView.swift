//
//  TicketOpenView.swift
//  TicketForm
//
//  Created by Rashad on 1/11/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.
//

import UIKit

@IBDesignable
class TicketOpenView: UIView {
    var view: UIView!
    
    var nibName: String = "TicketOpenView"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    func setup() {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        addSubview(view)
    }
    
    func loadViewFromNib() -> UIView {
        let bundle = Bundle(for:type(of: self))
        let nib = UINib(nibName: "TicketOpenView", bundle: bundle)
        let view = nib.instantiate(withOwner: self, options: nil)[0] as! UIView
        
        return view
    }
    
}
