//  Created by Rashad on 1/11/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.

import UIKit

@IBDesignable
class Ticket: UIView {
    override func draw(_ rect: CGRect) {
        // Color Declaration
        let color = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.000)
        // Shadow Offset
        let myShadowOffset = CGSize (width: 2.6,  height: 2.6)
        // Bezier Drawing
        let context = UIGraphicsGetCurrentContext()
        //  Shadow
        context?.setShadow(offset: myShadowOffset, blur: 14.9)
        //  Gradient Part
        let path1 = UIBezierPath()
        path1.move(to: CGPoint(x: 7.5, y: 2.5))
        path1.addLine(to: CGPoint(x: 332.5, y: 2.5))
        path1.addArc(withCenter: CGPoint(x: 332.5, y: 10), radius: 7.5, startAngle: -.pi/2, endAngle: 0, clockwise: true)
        path1.addLine(to: CGPoint(x: 340, y: 40))
        path1.addLine(to: CGPoint(x: 5, y: 40))
        path1.addLine(to: CGPoint(x: 5, y: 10))
        path1.addArc(withCenter: CGPoint(x: 12.5, y: 10), radius: 7.5, startAngle: -.pi, endAngle:-.pi/2 , clockwise: true)
        path1.close()
        path1.fit(into: rect).moveCenter(to: CGPoint(x: rect.center.x, y: rect.origin.y+self.frame.width*0.05)).fill()
        UIColor.black.setStroke()
        path1.lineWidth = 0
        color.setFill()
        path1.stroke()
        
        //  White part
        let path2 = UIBezierPath()
        path2.move(to: CGPoint(x: 5, y: 40))
        path2.addLine(to: CGPoint(x: 339.5, y: 40))
        path2.addLine(to: CGPoint(x: 339.5, y: 71.5))
        path2.addArc(withCenter: CGPoint(x: 339.5, y: 77.5), radius: 6, startAngle: -.pi/2, endAngle: .pi/2, clockwise: false)
        
        path2.addLine(to: CGPoint(x: 339.5, y: 173.5))
        path2.addArc(withCenter: CGPoint(x: 332, y: 182.5), radius: 7.5, startAngle: 0, endAngle: .pi/2, clockwise: true)
        path2.addLine(to: CGPoint(x: 5, y: 190))
        path2.addArc(withCenter: CGPoint(x: 12, y: 182.5), radius: 7.5, startAngle: .pi/2, endAngle: .pi, clockwise: true)
        path2.addLine(to: CGPoint(x: 5, y: 83.5))
        path2.addArc(withCenter: CGPoint(x: 5, y: 77.5), radius: 6, startAngle: .pi/2, endAngle: -.pi/2, clockwise: false)
        path2.close()
        path2.fit(into: rect).moveCenter(to: CGPoint(x: rect.center.x, y: rect.center.y+self.frame.width*0.01)).fill()
        UIColor.black.setStroke()
        path2.lineWidth = 0
        path2.stroke()
        
        //  Gradient on path1
        let red = UIColor(displayP3Red: 204/255, green: 49/255, blue: 120/255, alpha: 1)
        let purple = UIColor(displayP3Red: 158/255, green: 52/255, blue: 192/255, alpha: 1)
        drawLinearGradient(inside: path1, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 760, y: 20), colors: [red, purple])
    }
    
    // function for gradient
    func drawLinearGradient(inside path:UIBezierPath, start:CGPoint, end:CGPoint, colors:[UIColor])
    {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        ctx.saveGState()
        path.addClip() // use the path as the clipping region
        let cgColors = colors.map({ $0.cgColor })
        guard let gradient = CGGradient(colorsSpace: nil, colors: cgColors as CFArray, locations: [0.0, 1.0])
            else { return }
        ctx.drawLinearGradient(gradient, start: start, end: end, options: [])
        ctx.restoreGState() // remove the clipping region for future draw operations
    }
}

