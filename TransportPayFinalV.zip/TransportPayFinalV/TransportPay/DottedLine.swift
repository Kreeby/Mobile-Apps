//  Created by Rashad on 1/11/19.
//  Copyright © 2019 Rashad "Kreeby". All rights reserved.

import UIKit

@IBDesignable
class DottedLine: UIView {
    override func draw(_ rect: CGRect) {
        let  path = UIBezierPath()
        let  p0 = CGPoint(x: 0, y: 0)
        path.move(to: p0)
        let  p1 = CGPoint(x: 600, y: 0)
        path.addLine(to: p1)
        let  dashes: [ CGFloat ] = [ 2.5, 2.5 ]
        path.setLineDash(dashes, count: dashes.count, phase: 0.0)
        path.lineWidth = 1.0
        path.lineCapStyle = .butt
        UIColor.black.set()
        path.stroke()
        path.fit(into: rect).moveCenter(to: rect.center).fill()
    }
}
